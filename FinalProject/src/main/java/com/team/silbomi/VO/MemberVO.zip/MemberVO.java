package com.team.silbomi.VO;

public class MemberVO {
	
	//멤버변수
	private String user_id ;
	private String user_name;
	private String user_pw;
	private int user_type;
	private String silver_id;
	private String gender;
	private String birth;
	private String tel;
	private String mobile;
	private String smsAgree;
	private String email_id;
	private String email_domain;
	private String emailAgree;
	private String zipcode;
	private String addr1;
	private String addr2;
	
	//기본생성자
	public MemberVO() {}

	//인자생성자
	public MemberVO(String user_id, String user_name, String user_pw, int user_type, String silver_id, String gender,
			String birth, String tel, String mobile, String smsAgree, String email_id, String email_domain,
			String emailAgree, String zipcode, String addr1, String addr2) {
		this.user_id = user_id;
		this.user_name = user_name;
		this.user_pw = user_pw;
		this.user_type = user_type;
		this.silver_id = silver_id;
		this.gender = gender;
		this.birth = birth;
		this.tel = tel;
		this.mobile = mobile;
		this.smsAgree = smsAgree;
		this.email_id = email_id;
		this.email_domain = email_domain;
		this.emailAgree = emailAgree;
		this.zipcode = zipcode;
		this.addr1 = addr1;
		this.addr2 = addr2;
	}
}
